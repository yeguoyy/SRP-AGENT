# DeepSeek API 迁移说明（2026-08-22）

> 场景：在原项目 `calimero-network/ai-code-reviewer` 基础上，把原本基于
> **Anthropic Messages API** 的 LLM 调用层，迁移到了 **DeepSeek API**。
>
> **结论先行：DeepSeek 接口是"替换"了原来的 Anthropic 接口，二者不是"独立共存"**
> ——原项目里 Anthropic 相关的客户端/配置/依赖均已删除，运行时只会走 DeepSeek。

---

## 1. 为什么能直接换

DeepSeek 暴露的是 **OpenAI 兼容的 API**（`https://api.deepseek.com`），
请求、响应格式与 OpenAI `chat/completions` 一致。因此无需自己造 HTTP 请求，
直接用官方 `openai` SDK，把 `base_url` 指向 DeepSeek 即可。

> DeepSeek 同时提供"聊天模型"（本实现用的 `deepseek-v4-pro`）和"推理模型"
> （`deepseek-reasoner`）。推理模型不支持 function calling，所以本实现一律用
> `deepseek-v4-pro`。

---

## 2. 修改的文件清单

### 2.1 依赖：`pyproject.toml`

```diff
  dependencies = [
-     "anthropic>=...",
+     "openai>=1.30.0",
      ...
  ]
```

把 `anthropic` 依赖换成 `openai`（DeepSeek 官方推荐走 OpenAI 兼容层）。

### 2.2 核心新文件：`src/ai_reviewer/agents/deepseek_client.py`

新增 `DeepSeekClient`，替代原来的 `AnthropicClient`。文件 docstring 明确写着
"Replaces the former Anthropic Messages API client"。

实现要点：

- 构造时用 `openai.AsyncOpenAI(api_key=..., base_url="https://api.deepseek.com", ...)`。
- 提供两个方法：
  - `run_review(...)`：多智能体评审用的入口，**带 tool-use 循环 + JSON 模式**。
  - `run_completion(...)`：纯文本补全，用于文档草稿等不需要结构化输出的场景。
- 底层调用的是 `client.chat.completions.create(...)`（OpenAI 协议），model 用
  `deepseek-v4-pro`。

`run_review` 的智能体循环逻辑（对应原 Anthropic 的 tool-use）：

1. 拼 `system` + `user` 消息。
2. 若配置了工具（`tool_registry.tool_specs()`），传 `tools` 参数（OpenAI 风格
   function calling）；
   否则走 `response_format = {"type": "json_object"}` 强制返回 JSON。
3. 循环判断 `finish_reason == "tool_calls"`：
   - 是 → 把 assistant 的 `tool_calls` 追加进消息，逐个 `await tool_registry.execute(...)`，
     再把结果以 `role="tool"` + `tool_call_id` 回填，继续下一轮（上限 `max_tool_rounds`）。
   - 否 → 视为最终 JSON 评审结果，交给 `_parse_json` 解析返回。
4. `enable_thinking` 参数仅做接口兼容保留（**无实际作用**），因为推理模型不支持
   function calling。

配套的解析/统计辅助函数：`_parse_json`（剥离 ```` ```json ```` 围栏、容错）、
`_accumulate_usage`（OpenAI 的 `prompt_tokens` / `completion_tokens`）。

### 2.3 配置：`src/ai_reviewer/config.py`

- `AnthropicApiConfig` → `DeepSeekApiConfig`，字段改为 `api_key`、`base_url`、
  `timeout_seconds`、`max_retries`、`default_model`、`enable_prompt_caching` 等。
- 环境变量：`ANTHROPIC_API_KEY` → `DEEPSEEK_API_KEY`。
- 默认模型：`deepseek-v4-pro`。

### 2.4 智能体基类与子类：`agents/base.py`、`security.py`、`patterns.py`、`performance.py`

- `ReviewAgent.__init__` 接收的类型由 `AnthropicClient` 换成 `DeepSeekClient`，并新增
  `model` 参数（见第 6 节，模型已统一由 config 驱动）。
- `ReviewAgent.MODEL`、各领域智能体（security / patterns / performance 等）的 `MODEL`
  保留为 `deepseek-v4-pro`，**仅作为未传 model 时的兜底默认值**。
- System Prompt 与审查重点保持不变。

### 2.5 导出：`src/ai_reviewer/agents/__init__.py`

把 `AnthropicClient` 的导出替换为 `DeepSeekClient` / `DeepSeekReviewResult`。

### 2.6 主流程与入口

- `src/ai_reviewer/review.py`：`review_pr(...)` 用 `async with DeepSeekClient(cfg)`，
  `_prepare_shared_context`、cross-review 轮次均改为传 `DeepSeekClient` / `DeepSeekApiConfig`。
- `src/ai_reviewer/cli.py`、`src/ai_reviewer/github/webhook.py`：读取 `DEEPSEEK_API_KEY`
  / `DEEPSEEK_BASE_URL` 等环境变量，构造 `DeepSeekApiConfig`。
- `src/ai_reviewer/docs/analyzer.py`、`src/ai_reviewer/docs/updater.py`：文档分析与
  文档草稿生成改用 `DeepSeekClient.run_completion`。

### 2.7 配置文件

- `config.example.yaml` / `config.yaml`：新增 `deepseek:` 配置段（api_key、default_model 等），
  移除原先的 anthropic 配置段。

### 2.8 测试

- 删除 `tests/test_anthropic_client.py`，新增 `tests/test_deepseek_client.py`，
  用 mock 的 OpenAI ChatCompletion 响应覆盖：JSON 解析、无工具时用
  `response_format`、有工具时的 tool-use 循环回填、纯文本补全等分支。

---

## 3. DeepSeek 接口是否独立于原有 Anthropic 接口？

**不独立——是完全替换。** 依据如下：

1. `deepseek_client.py` 自己的模块 docstring 即声明
   "Replaces the former Anthropic Messages API client"。
2. 全仓源码中搜索 `anthropic`，只剩 `deepseek_client.py` 里的两处注释，**没有任何
   Anthropic 客户端源码/类/导入存在**。
3. `agents/__init__.py` 只导出 `DeepSeekClient`，不再有 `AnthropicClient`。
4. `pyproject.toml` 依赖已从 `anthropic` 换成 `openai`。
5. 配置类 `AnthropicApiConfig`、环境变量 `ANTHROPIC_API_KEY` 均已移除，由
   `DeepSeekApiConfig` / `DEEPSEEK_API_KEY` 取代。
6. 测试文件 `test_anthropic_client.py` 已被 `test_deepseek_client.py` 替代。

**含义**：当前代码 **没有同时保留 Anthropic 调用能力**。若未来想支持
"Anthropic / DeepSeek 多后端切换"，需要主动重构，把 `DeepSeekClient` 抽成一个
通用协议接口再做 `AnthropicClient` / `DeepSeekClient` 两套实现；目前架构不具备
该能力，DeepSeek 是唯一选择。

---

## 4. 使用方式

```bash
# config.yaml 配置 DEEPSEEK_API_KEY，或设置环境变量
export DEEPSEEK_API_KEY=sk-...
export GITHUB_TOKEN=ghp_...

# 评审某个 PR
ai-reviewer review-pr owner/repo <pr-number>
```

---

## 5. 注意事项 / 已知取舍

- 模型已由 `config.yaml` 驱动，无需改代码即可切换（详见第 6 节）。
- `enable_thinking` 当前为占位参数（无效果），因为推理模型 `deepseek-reasoner`
  不支持 function calling。
- 输出强制 JSON 依赖 `response_format={"type":"json_object"}`；DeepSeek 对该模式
  要求 prompt 中含 "json" 字样，现有 prompt（`Output Format` 提示）已满足。

---

## 6. 模型配置重构（2026-08-23，改为 config 驱动）

### 背景

初版迁移后，模型名 `deepseek-v4-pro` 在 **多处被硬编码**，而 config 里的
`deepseek.default_model` 与 `agents[].model` 只用于 `config show` 显示，并不真正
决定评审调用的模型。本次重构让模型实打实地由 `config.yaml` 驱动。

### 改动点

| 文件 | 改动 |
|------|------|
| `agents/base.py` | `ReviewAgent.__init__` 新增 `model` 参数，存为 `self._model`；`review()` 用 `self._model`。优先级：传入的 `model` > 类属性 `MODEL`（兜底） |
| `review.py` | 实例化 agent 时传 `model=agent_cfg.model if agent_cfg else deepseek_cfg.default_model` |
| `review.py` | cross-review 的 `_run_single_cross_agent`、`run_cross_review_round` 新增 `model` 参数，移除硬编码字面量，兜底取 `deepseek.default_model` |
| `docs/analyzer.py` | `generate_doc_drafts` 默认 `model=None`，未传时回退到 `deepseek_cfg.default_model` |
| `docs/updater.py` | 无需改动（已由 `doc_generation.model` 驱动） |
| `agents/{security,patterns,performance}.py` | `MODEL` 保留为兜底默认值，不再参与实际生效 |

### 现在的模型解析优先级

- **评审 agent**（`review-pr` / webhook）：对应 `agents[].model`；某 agent 未配置时用
  `deepseek.default_model`。
- **cross-review 轮次**：`deepseek.default_model`。
- **文档草稿生成**（`ai-reviewer update-docs`）：`doc_generation.model`（可被仓库
  `.ai-reviewer.yaml` 的 `doc_generation.model` 覆盖）。

### 切换模型的方式（只改编 `config.yaml`）

```yaml
deepseek:
  default_model: deepseek-chat      # 全局切换：影响所有未单独指定 model 的 agent + cross-review
  ...
agents:
  - name: security-reviewer
    model: deepseek-chat            # 或逐个 agent 单独指定
```

### 校验

- 4 个改动文件 `py_compile` 通过，`ai_reviewer` 全模块导入正常。
- 传入自定义 model 时 `_model` 正确覆盖类默认值；不传时正确回退到 `deepseek-v4-pro`。