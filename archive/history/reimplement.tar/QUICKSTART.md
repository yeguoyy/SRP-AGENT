# 快速启动指南

本指南帮助你在几分钟内完成 AI Code Reviewer 的安装、配置并运行第一次代码评审。

> 本项目已迁移至 **DeepSeek** 大模型，默认使用 `deepseek-v4-pro`，通过 DeepSeek 官方 OpenAI 兼容端点 (`https://api.deepseek.com`) 调用。

***

## 致谢（Acknowledgement）

本项目是 [calimero-network/ai-code-reviewer](https://github.com/calimero-network/ai-code-reviewer)
的 fork，基于 **MIT 协议**，并在此基础上新增了 **DeepSeek API** 支持。
原项目版权归 **Calimero Network** 所有。

***

## 1. 前置条件

| 依赖               | 最低版本  | 说明                                                                   |
| ---------------- | ----- | -------------------------------------------------------------------- |
| Python           | 3.11+ | 需要 `asyncio`、`typing.Self` 等特性                                       |
| pip / uv         | 任意    | 推荐使用 [uv](https://github.com/astral-sh/uv) 加速虚拟环境与依赖安装               |
| DeepSeek API Key | —     | 在 [platform.deepseek.com](https://platform.deepseek.com) 创建，`sk-` 开头 |
| GitHub Token     | —     | 需 `repo` / `pull_requests: write` 权限，用于读取 PR 并提交评审                   |

> DeepSeek API Key 示例：`sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`

***

## 2. 安装

本项目的安装方式均为**从源码安装**，按包管理器分为 **pip** 与 **uv** 两种方式，任选其一。

```bash
# 先克隆源码（项目仅以源码方式安装）
git clone https://github.com/kun940/ai-coder-reviewer-master-Reimplement.git
cd ai-code-reviewer
```

### 方式一：pip 从源码安装

```bash
# 创建虚拟环境
python -m venv .venv

# 激活虚拟环境
# Windows (PowerShell)
.venv\Scripts\Activate.ps1
# macOS / Linux
source .venv/bin/activate

# 安装依赖（含开发依赖）
pip install -e ".[dev]"
```

### 方式二：uv 从源码安装（推荐）

```bash
# uv 会自动创建并管理 .venv（若已有 .venv 会自动复用）
uv venv            # 可选：显式创建虚拟环境（可省略，uv sync 会自动建）

# 安装依赖（含开发依赖），后续直接用 uv run 即可，无需手动激活
uv sync
```

安装完成后，可用 `uv run` 直接执行命令；若想先进激活环境，可执行 `.venv\Scripts\Activate.ps1`（Windows）或 `source .venv/bin/activate`（macOS / Linux）。

> 📌 **两种方式的等价调用**
>
> **pip 安装**（需先激活 venv）：
>
> ```bash
> ai-reviewer --version
> ```
>
> **uv 安装**（无需激活）：
>
> ```bash
> uv run ai-reviewer --version
> ```
>
> 若 `ai-reviewer` 命令未生成脚本入口，可改用 `python -m ai_reviewer.cli` 调用：
>
> ```bash
> uv run python -m ai_reviewer.cli --version
> ```

***

## 3. 配置凭证

AI Code Reviewer 支持两种配置方式：**环境变量**（快速试用）或 **配置文件**（生产 / 多参数场景）。

### 方式一：设置环境变量

```bash
# DeepSeek API
export DEEPSEEK_API_KEY=sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

# GitHub PAT（需读取 PR、提交评审）
export GITHUB_TOKEN=ghp_xxxxxxxxxxxxxxxxxxxxxxxx
```

Windows PowerShell：

```powershell
$env:DEEPSEEK_API_KEY = "sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
$env:GITHUB_TOKEN     = "ghp_xxxxxxxxxxxxxxxxxxxxxxxx"
```

| 环境变量                       | 必填 | 默认值                        | 说明                           |
| -------------------------- | -- | -------------------------- | ---------------------------- |
| `DEEPSEEK_API_KEY`         | 是  | —                          | DeepSeek 平台 API Key          |
| `GITHUB_TOKEN`             | 是  | —                          | GitHub Personal Access Token |
| `DEEPSEEK_BASE_URL`        | 否  | `https://api.deepseek.com` | 自定义 DeepSeek 端点（如代理）         |
| `DEEPSEEK_TIMEOUT`         | 否  | `300`                      | 单次请求超时（秒）                    |
| `NUM_AGENTS`               | 否  | `3`                        | webhook 模式下并行 agent 数量       |
| `MIN_VALIDATION_AGREEMENT` | 否  | `0.667`                    | 交叉评审共识阈值（0–1）                |

### 方式二：配置文件（推荐使用）

```bash
cp config.example.yaml config.yaml
```

编辑 `config.yaml` 关键字段：

```yaml
deepseek:
  api_key: 你的DEEPSEEK_API_KEY       # 
  base_url: https://api.deepseek.com  # 默认值，可改代理
  default_model: deepseek-v4-pro      # 默认模型
  timeout_seconds: 300
  enable_prompt_caching: false        # DeepSeek 端不支持 Anthropic 缓存

github:
  token: 你的GITHUB_TOKEN

agents:
  - name: security-reviewer
    model: deepseek-v4-pro
    focus_areas: [security, authentication]
    allow_tool_use: true
    max_tool_calls: 20
  # ... 其余 agent 见 config.example.yaml
```

> 完整字段说明见 [config.example.yaml](config.example.yaml)。

***

## 4. 运行第一次评审

### 4.1 评审 GitHub PR（最常用）

语法（`OWNER/REPO` 和 `PR_NUMBER` 替换为实际值，**不要带尖括号**）：

```bash
ai-reviewer review-pr OWNER/REPO PR_NUMBER
```

示例：

```bash
ai-reviewer review-pr calimero-network/core 123
```

默认行为：3 个专门 agent（安全 / 性能 / 质量）并行评审 + 交叉验证，结果以 GitHub Review 形式提交到 PR。

> ⚠️ **PowerShell 用户注意**：不要使用 `<owner>/<repo>` 这种带尖括号的占位符写法——PowerShell 会把 `<` `>` 当作重定向运算符报错。直接写实际值即可，如 `ai-reviewer review-pr kun940/AutoResAgent 1`。

### 4.2 常用参数

| 参数                     | 说明                                  | 示例                         |
| ---------------------- | ----------------------------------- | -------------------------- |
| `--agents N`           | 并行 agent 数（1=综合, 2=安全+性能, 3=默认）     | `--agents 1`               |
| `--output FORMAT`      | 输出格式：`github` / `json` / `markdown` | `--output markdown`        |
| `--dry-run`            | 不提交到 GitHub，仅本地打印                   | `--dry-run`                |
| `--no-cross-review`    | 跳过第二轮交叉验证                           | `--no-cross-review`        |
| `--min-agreement FRAC` | 共识阈值（0–1，需多少比例 agent 认同）            | `--min-agreement 0.5`      |
| `--force-review`       | 跳过收敛检测，强制输出评审                       | `--force-review`           |
| `--reviewer-name NAME` | 评审署名                                | `--reviewer-name "My Bot"` |
| `--config PATH`        | 指定配置文件                              | `--config ./prod.yaml`     |

### 4.3 典型场景

**仅本地预览，不提交 GitHub：**

```bash
ai-reviewer review-pr owner/repo 42 --output markdown --dry-run
```

**单 agent 快速评审：**

```bash
ai-reviewer review-pr owner/repo 42 --agents 1 --no-cross-review
```

**调整共识阈值并强制评审：**

```bash
ai-reviewer review-pr owner/repo 42 --min-agreement 0.5 --force-review
```

***

## 5. 其他命令

### 5.1 文档更新（`update-docs`）

针对已合并的 PR，自动生成文档更新草案并提交 PR 供人工审阅。

```bash
ai-reviewer update-docs owner/repo 456 --dry-run    # 预览
ai-reviewer update-docs owner/repo 456               # 实际提交 doc PR
```

| 参数              | 说明                   |
| --------------- | -------------------- |
| `--dry-run`     | 仅打印生成内容，不创建 PR       |
| `--base BRANCH` | doc PR 的目标分支（默认自动检测） |
| `--config PATH` | 指定配置文件               |

> 需在仓库根目录 `.ai-reviewer.yaml` 中启用 `doc_generation.enabled: true`。

### 5.2 Webhook 服务（`serve`）【详见WEBHOOK-GUIDE.md】

启动 HTTP 服务，监听 GitHub Webhook 事件，PR 打开 / 同步时自动评审。

```bash
ai-reviewer serve --port 8080 --host 0.0.0.0
```

| 参数              | 默认        | 说明     |
| --------------- | --------- | ------ |
| `--port`        | `8080`    | 监听端口   |
| `--host`        | `0.0.0.0` | 绑定地址   |
| `--config PATH` | —         | 配置文件路径 |

Webhook 模式下，配置从环境变量读取（见第 3 节表格）。GitHub App 认证可选：

```bash
export GITHUB_APP_ID=123456
export GITHUB_APP_PRIVATE_KEY="$(cat github-app.pem)"
```

***

## 6. 验证安装

执行以下命令确认安装与配置无误：

```bash
# 查看版本
ai-reviewer --version

# 查看当前生效配置（API key 会脱敏）
ai-reviewer config show
```

预期输出包含：

```
DeepSeek API: https://api.deepseek.com
Model:        deepseek-v4-pro
Timeout:      300s
```

跑一次最小评审（dry-run）确认端到端通路（替换 `OWNER/REPO` 和 `PR_NUMBER`）：

```bash
ai-reviewer review-pr OWNER/REPO PR_NUMBER --agents 1 --dry-run --output markdown
```

***

## 7. 常见问题

### Q1：报错 `DEEPSEEK_API_KEY not set`

- 确认环境变量已导出（`echo $DEEPSEEK_API_KEY`）
- 或在 `config.yaml` 的 `deepseek.api_key` 字段直接填写

### Q2：报错 `openai` 模块未找到

DeepSeek 客户端依赖 `openai` SDK（≥1.30）。从源码安装时确认依赖已装：

```bash
pip install openai>=1.30.0
# 或
uv pip install "openai>=1.30.0" --python .venv\Scripts\python.exe
```

### Q3：GitHub 评审提交失败（403 / 401）

- 确认 `GITHUB_TOKEN` 未过期
- 确认 token 对目标仓库有 `pull_requests: write` 权限
- GitHub App 安装到目标仓库后才会生效

### Q4：DeepSeek 调用超时

- 调大 `DEEPSEEK_TIMEOUT` 环境变量或 `config.yaml` 中的 `deepseek.timeout_seconds`
- 减少 `--agents` 数量或加 `--no-cross-review` 降低调用次数

### Q5：如何切换到其他 DeepSeek 模型？

在 `config.yaml` 中修改 `deepseek.default_model` 与各 agent 的 `model` 字段，或通过环境变量在 webhook 模式覆盖：

```yaml
deepseek:
  default_model: deepseek-reasoner   # 注意：reasoner 不支持函数调用
```

> ⚠️ `deepseek-reasoner` 当前不支持 function calling，启用工具调用的 agent 必须使用 `deepseek-v4-pro` 或 `deepseek-chat`。

***

## 8. 下一步

- 完整架构与流水线原理：[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)
- 全部配置项示例：[config.example.yaml](config.example.yaml)
- 生产部署（GitHub App / Webhook）：参考 README 的 Deployment 章节

