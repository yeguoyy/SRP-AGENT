"""DeepSeek chat completions client with tool-use loop.

Replaces the former Anthropic Messages API client. DeepSeek exposes an
OpenAI-compatible API, so we use the official ``openai`` SDK with
``base_url`` pointed at ``https://api.deepseek.com``.
"""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from typing import Any

import openai

from ai_reviewer.config import DeepSeekApiConfig

logger = logging.getLogger(__name__)


@dataclass
class UsageStats:
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_input_tokens: int = 0
    cache_creation_input_tokens: int = 0


@dataclass
class DeepSeekReviewResult:
    parsed: dict[str, Any]
    raw_text: str
    usage: UsageStats = field(default_factory=UsageStats)
    tool_calls: list[dict[str, Any]] = field(default_factory=list)


class DeepSeekClient:
    """Thin wrapper over the openai SDK targeting the DeepSeek API."""

    def __init__(self, config: DeepSeekApiConfig) -> None:
        self.config = config
        self._sdk = openai.AsyncOpenAI(
            api_key=config.api_key,
            base_url=config.base_url,
            timeout=config.timeout_seconds,
            max_retries=config.max_retries,
        )

    async def run_completion(
        self,
        model: str,
        system: str,
        user: str,
        max_tokens: int = 4096,
        temperature: float = 0.3,
    ) -> str:
        """Plain text completion — no tool use, no JSON schema.

        Used for prose generation tasks (e.g. doc drafting) where structured
        output is not needed.
        """
        response = await self._sdk.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            max_tokens=max_tokens,
            temperature=temperature,
        )
        return _extract_text(response)

    async def close(self) -> None:
        await self._sdk.close()

    async def __aenter__(self) -> DeepSeekClient:
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.close()

    async def run_review(
        self,
        model: str,
        system_blocks: list[dict[str, Any]],
        user_blocks: list[dict[str, Any]],
        output_schema: dict[str, Any],
        tool_registry: Any,
        enable_thinking: bool = False,
        max_tokens: int = 8192,
        temperature: float = 0.3,
        max_tool_rounds: int = 30,
    ) -> DeepSeekReviewResult:
        """Run a review with optional tool-use loop.

        DeepSeek (deepseek-v4-pro) supports OpenAI-style function calling.
        ``enable_thinking`` is accepted for interface compatibility but has
        no effect — DeepSeek's reasoning model (deepseek-reasoner) does not
        support function calling, so we always use deepseek-v4-pro here.
        """
        system_text = _blocks_to_text(system_blocks)
        user_text = _blocks_to_text(user_blocks)

        messages: list[dict[str, Any]] = [
            {"role": "system", "content": system_text},
            {"role": "user", "content": user_text},
        ]
        usage = UsageStats()
        tool_calls: list[dict[str, Any]] = []

        tools = tool_registry.tool_specs() if tool_registry else None

        for _ in range(max_tool_rounds + 1):
            kwargs: dict[str, Any] = {
                "model": model,
                "messages": messages,
                "max_tokens": max_tokens,
                "temperature": temperature,
            }
            if tools:
                kwargs["tools"] = tools
            else:
                # Only enforce JSON mode when there are no tools — the model
                # returns the final JSON review once tool exploration is done.
                kwargs["response_format"] = {"type": "json_object"}

            response = await self._sdk.chat.completions.create(**kwargs)
            _accumulate_usage(usage, response)

            choice = response.choices[0]
            message = choice.message
            finish_reason = choice.finish_reason

            if finish_reason != "tool_calls" or not tool_registry:
                raw_text = message.content or ""
                return DeepSeekReviewResult(
                    parsed=_parse_json(raw_text),
                    raw_text=raw_text,
                    usage=usage,
                    tool_calls=tool_calls,
                )

            # Append the assistant message (with tool_calls) to the conversation
            messages.append(_serialize_assistant_message(message))

            for tc in message.tool_calls or []:
                tool_name = tc.function.name
                try:
                    tool_args = json.loads(tc.function.arguments)
                except (json.JSONDecodeError, TypeError):
                    tool_args = {}
                tool_calls.append({"name": tool_name, "input": tool_args})
                try:
                    tool_output = await tool_registry.execute(tool_name, tool_args)
                except Exception as e:  # noqa: BLE001
                    tool_output = f"[tool error: {e}]"
                    logger.warning("Tool %s failed: %s", tool_name, e)
                messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": tc.id,
                        "content": tool_output,
                    }
                )

        logger.warning("Tool-use loop exceeded max_tool_rounds=%d", max_tool_rounds)
        return DeepSeekReviewResult(
            parsed={"findings": [], "summary": "[tool loop cap]"},
            raw_text="",
            usage=usage,
            tool_calls=tool_calls,
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _accumulate_usage(u: UsageStats, response: Any) -> None:
    ru = getattr(response, "usage", None)
    if not ru:
        return
    u.input_tokens += getattr(ru, "prompt_tokens", 0) or 0
    u.output_tokens += getattr(ru, "completion_tokens", 0) or 0


def _blocks_to_text(blocks: list[dict[str, Any]]) -> str:
    """Flatten Anthropic-style content blocks into a single text string."""
    parts: list[str] = []
    for b in blocks:
        if isinstance(b, dict):
            parts.append(b.get("text", ""))
        else:
            parts.append(getattr(b, "text", ""))
    return "\n\n".join(parts)


def _extract_text(response: Any) -> str:
    choice = response.choices[0]
    return choice.message.content or ""


def _serialize_assistant_message(message: Any) -> dict[str, Any]:
    """Convert an OpenAI ChatCompletionMessage to a dict for the next request."""
    msg: dict[str, Any] = {"role": "assistant", "content": message.content or ""}
    if message.tool_calls:
        msg["tool_calls"] = [
            {
                "id": tc.id,
                "type": "function",
                "function": {
                    "name": tc.function.name,
                    "arguments": tc.function.arguments,
                },
            }
            for tc in message.tool_calls
        ]
    return msg


def _parse_json(text: str) -> dict[str, Any]:
    text = text.strip()
    if "```json" in text:
        m = re.search(r"```json\s*([\s\S]*?)```", text)
        if m:
            text = m.group(1).strip()
    elif "```" in text:
        m = re.search(r"```\s*([\s\S]*?)```", text)
        if m:
            text = m.group(1).strip()
    m = re.search(r"\{[\s\S]*\}", text)
    if m:
        text = m.group(0)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        logger.warning("Failed to parse JSON: %r", text[:200])
        return {"findings": [], "summary": "[parse error]"}
