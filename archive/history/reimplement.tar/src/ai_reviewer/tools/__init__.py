"""Tool implementations for DeepSeek (OpenAI-compatible) function calling."""
