# Webhook 服务使用指南

本指南介绍如何使用 `ai-reviewer serve` 启动 webhook 服务,自动监听 GitHub 仓库事件并触发 AI 代码评审。

---

## 1. 概述

webhook 服务基于 FastAPI 实现([src/ai_reviewer/github/webhook.py](src/ai_reviewer/github/webhook.py)),通过 `ai-reviewer serve` 命令启动,监听 GitHub 仓库的 webhook 事件并自动触发评审或文档更新。

### 暴露的 HTTP 端点

| 方法 | 路径 | 用途 |
|---|---|---|
| `GET` | `/` | 服务信息 |
| `GET` | `/health` | 健康检查(Cloud Run 探活) |
| `POST` | `/webhook` | 接收 GitHub 事件 |

### 支持的 GitHub 事件

| 事件类型 | 触发动作 | 行为 |
|---|---|---|
| `pull_request` | `opened` / `synchronize` / `reopened` | 自动评审 PR |
| `issue_comment` | 评论内容以 `/ai-review` 开头 | 触发该 PR 的评审 |
| `push` | 合并到 `main` / `master` | 调用 `update-docs` 生成文档 PR |
| `ping` | — | 返回 pong(初次配置 webhook 时验证用) |

---

## 2. 启动服务

### 基本命令

```bash
ai-reviewer serve --port 8080 --host 0.0.0.0
```

| 参数 | 默认值 | 说明 |
|---|---|---|
| `--port` | `8080` | 监听端口 |
| `--host` | `0.0.0.0` | 绑定地址 |
| `--config PATH` | — | 配置文件路径(默认按 `config.yaml` → `config.example.yaml` 顺序查找) |

> 用 uv 安装时,命令前加 `uv run`,例如 `uv run ai-reviewer serve --port 8080`。

### 启动成功标志

日志应出现:

```
🚀 Starting webhook server on 0.0.0.0:8080
INFO:     Application startup complete.
INFO:     Uvicorn running on http://0.0.0.0:8080
```

访问 `http://localhost:8080/health` 应返回:

```json
{"status": "healthy", "service": "ai-code-reviewer"}
```

---

## 3. 配置凭证

webhook 服务启动时一次性加载配置,token 解析逻辑见 [src/ai_reviewer/config.py:228](src/ai_reviewer/config.py#L228)。

### 方式 A:直接写入 config.yaml(推荐,免每次 export)

```yaml
deepseek:
  api_key: sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
  default_model: deepseek-v4-pro
  timeout_seconds: 300

github:
  token: ghp_xxxxxxxxxxxxxxxxxxxxxxxx
  # webhook_secret: your-webhook-secret   # 可选,用于签名校验
```

启动:

```bash
ai-reviewer serve --config ./config.yaml --port 8080
```

> ⚠️ 明文 token 不要提交到 git,确保 `config.yaml` 已加入 `.gitignore`。

### 方式 B:环境变量(适合容器化部署)

config.yaml 用占位符:

```yaml
deepseek:
  api_key: ${DEEPSEEK_API_KEY}

github:
  token: ${GITHUB_TOKEN}
  webhook_secret: ${GITHUB_WEBHOOK_SECRET}
```

启动前在 shell 里 export(PowerShell 用 `$env:`,bash 用 `export`):

```bash
# bash
export DEEPSEEK_API_KEY=sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
export GITHUB_TOKEN=ghp_xxxxxxxxxxxxxxxxxxxxxxxx
export GITHUB_WEBHOOK_SECRET=your-webhook-secret

ai-reviewer serve --port 8080
```

```powershell
# PowerShell
$env:DEEPSEEK_API_KEY = "sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
$env:GITHUB_TOKEN     = "ghp_xxxxxxxxxxxxxxxxxxxxxxxx"
$env:GITHUB_WEBHOOK_SECRET = "your-webhook-secret"

ai-reviewer serve --port 8080
```

> ⚠️ **关键**:环境变量只在进程启动时被读取一次。如果 `serve` 正在运行,事后设置环境变量不会生效,必须重启服务。

### 支持的环境变量

| 变量 | 必填 | 默认值 | 说明 |
|---|---|---|---|
| `DEEPSEEK_API_KEY` | 是 | — | DeepSeek 平台 API Key |
| `GITHUB_TOKEN` | 是 | — | GitHub Personal Access Token |
| `DEEPSEEK_BASE_URL` | 否 | `https://api.deepseek.com` | 自定义 DeepSeek 端点 |
| `DEEPSEEK_TIMEOUT` | 否 | `300` | 单次请求超时秒数 |
| `NUM_AGENTS` | 否 | `3` | 并行 agent 数量 |
| `MIN_VALIDATION_AGREEMENT` | 否 | `0.667` | 交叉评审共识阈值(0–1) |
| `MAX_TOTAL_FINDINGS` | 否 | `50` | 单次评审最多上报问题数 |
| `MAX_FINDINGS_PER_FILE` | 否 | `10` | 单文件最多 inline 评论数 |
| `ENABLE_CROSS_REVIEW` | 否 | `true` | 是否启用交叉验证 |
| `GITHUB_WEBHOOK_SECRET` | 否 | — | webhook 签名校验密钥 |
| `GITHUB_APP_ID` | 否 | — | GitHub App ID(生产推荐) |
| `GITHUB_APP_PRIVATE_KEY` | 否 | — | GitHub App PEM 私钥 |

### Token 类型选择

| Token 类型 | 支持 post review | 支持 inline comment | 支持 resolve thread | 适用场景 |
|---|---|---|---|---|
| Classic PAT(`repo` scope) | ✅ | ✅ | ✅ | **推荐**,完整功能 |
| Fine-grained PAT | ✅ | ✅ | ❌ | 不支持 GraphQL `resolveReviewThread` |
| GitHub Actions `GITHUB_TOKEN` | ✅ | ✅ | ❌ | 仅限 Actions 内使用 |

---

## 4. GitHub 仓库配置 webhook

1. 进入仓库 **Settings → Webhooks → Add webhook**
2. **Payload URL**:`http://<你的公网地址>:8080/webhook`
3. **Content type**:`application/json`
4. **Secret**:与 `GITHUB_WEBHOOK_SECRET` 一致(可选,用于签名校验)
5. **Events** 勾选:
   - `Pull requests`
   - `Issue comments`
   - `Pushes`

> 本地调试可用 ngrok / cloudflared 暴露临时公网:
> ```bash
> ngrok http 8080
> ```
> 把 ngrok 给的 `https://xxx.ngrok-free.app/webhook` 填到 GitHub。

配置完成后 GitHub 会发一次 `ping`,服务端日志应出现:

```
INFO:     "POST /webhook HTTP/1.1" 200 OK
Received ping from GitHub
```

---

## 5. 触发评审

### 5.1 自动触发

满足以下任一条件,webhook 会自动触发评审:

- PR 被打开(`opened`)
- PR 有新提交(`synchronize`)
- PR 重新打开(`reopened`)

### 5.2 手动触发

在 PR 评论框输入 `/ai-review`,服务端日志会出现:

```
Triggering review via /ai-review comment on OWNER/REPO PR #N
```

### 5.3 强制评审

如果同一 commit 多次推送,或评审结果已收敛,服务会自动跳过。绕过方式:

- 给 PR 加上 `force-review` label,下次推送或 `/ai-review` 评论时强制评审

---

## 6. 评审结果出现的位置

一次完整评审的结果会以**四种形式**提交到 PR:

### 6.1 Review Summary(评审摘要)

**位置**:PR → Conversation → Reviews 区域

包含:agent 数量、质量评分、按严重程度分组的发现列表(CRITICAL / WARNING / SUGGESTION / NITPICK)、review 元数据(commit_sha、review_count)。

### 6.2 Inline Comments(行内评论)

**位置**:PR → Files changed → 代码行右侧气泡

每条评论格式:

```
🔴 **问题标题**

问题描述

**Suggested fix:**
\`\`\`
代码建议
\`\`\`

<!-- ai-reviewer-id: <hash> -->
```

末尾的 `ai-reviewer-id` 是隐藏 HTML 注释,用于跨推送追踪同一问题(收敛检测和"已修复"识别靠它)。

### 6.3 Issue Comment(回退方案)

**位置**:PR → Conversation → 普通评论区

仅在以下情况触发:
- PR 上已有 pending review(422 错误),且重试仍然失败
- 此时 inline 评论会丢失,只剩 body 作为普通 issue comment 发布

### 6.4 Resolved Threads(已修复的旧问题)

**位置**:之前评审评论的回复区,标记为 "Resolved"

当本次评审没检测到上次报告过的某个问题,会:
- 在原 review comment 下回复 "Resolved" 消息
- 调用 GraphQL `resolveReviewThread` 把整个 thread 折叠

> ⚠️ 仅 Classic PAT 能调用 `resolveReviewThread`,fine-grained PAT 会静默跳过(评论仍发出,但 thread 不折叠)。

### 6.5 在 GitHub 上快速查看

1. **总览**:PR → Conversation → Reviews 区域
2. **逐文件查看**:PR → Files changed → 代码行右侧气泡
3. **看已解决问题**:PR → Conversation → 勾选 "Resolved conversations"

---

## 7. 评审流程内部行为

webhook 触发的评审有几条额外优化逻辑:

### 7.1 LGTM 快速路径

如果检测到上次评审发现已全部修复,只跑 1 个 agent 复查:
- 确认无新问题 → 发一条 LGTM 摘要(不再发 inline 评论)
- 发现新问题 → 回退到正常评审流程

### 7.2 收敛检测

同一 commit 多次推送,或发现数稳定不变,自动跳过评审。日志:

```
Convergence detected for OWNER/REPO PR #N — skipping post
```

### 7.3 Agent 数量自动缩减

小 PR 会自动减少 agent 数量:

```
Effective agent count: 2 (requested 3)
```

逻辑见 [src/ai_reviewer/review.py:1234](src/ai_reviewer/review.py#L1234)。

---

## 8. 验证配置

### 8.1 查看 token 加载状态

```bash
ai-reviewer config show
```

输出末尾会显示(脱敏):

```
GitHub Token: ghp_...abcd (len=40)
Webhook Secret: (set)
```

| 输出 | 判断 |
|---|---|
| `(not set)` | token 没加载,环境变量未设置或 config.yaml 写法不对 |
| `ghp_...xxxx (len=40)` | Classic PAT,加载正常 |
| `github_pat_...xxxx (len=93)` | fine-grained PAT,加载正常但可能无法 resolve thread |

### 8.2 测试 token 有效性

```bash
curl -H "Authorization: token ghp_你的token" https://api.github.com/user
```

- 返回用户信息 JSON → token 有效
- 返回 `{"message": "Bad credentials"}` → token 已失效

### 8.3 本地预览(不提交 GitHub)

```bash
ai-reviewer review-pr owner/repo 42 --dry-run --output markdown
```

---

## 9. 错误排查

### 9.1 `BadCredentialsException(401 {"message": "Bad credentials"})`

**原因**:GitHub token 未加载或已失效。

**排查步骤**:

1. `ai-reviewer config show` 看 `GitHub Token` 字段
2. 若为 `(not set)`:
   - config.yaml 写的是 `${GITHUB_TOKEN}` → 检查启动 shell 是否 `export GITHUB_TOKEN`
   - config.yaml 写的是明文 → 检查字段名是否为 `github.token`
3. 若显示 token 但仍 401:
   - 用 `curl -H "Authorization: token ghp_xxx" https://api.github.com/user` 测试有效性
   - 如失效,去 https://github.com/settings/tokens/new 生成新的 Classic PAT(勾选 `repo` scope)

### 9.2 `400 Bad Request - The supported API model names are ...`

**原因**:DeepSeek API **严格区分大小写**,模型名必须全小写。

**正确写法**:

| 错误 | 正确 |
|---|---|
| `DeepSeek-V4-Pro` | `deepseek-v4-pro` |
| `DeepSeek-V4-Flash` | `deepseek-v4-flash` |

修改 config.yaml 里所有 `model` 字段后重启 serve。

### 9.3 `Could not fetch ... 'utf-8' codec can't decode byte 0x8c`

**原因**:PR 改动包含二进制文件(`.bin` / `.sqlite3` / `.png` 等),代码按文本读取失败。

**影响**:仅 `WARNING` 级别,自动跳过,不影响评审。

**消除噪音**:在被评审仓库根目录加 `.ai-reviewer.yaml`:

```yaml
ignore:
  - "**/chroma_db/**"
  - "**/*.bin"
  - "**/*.sqlite3"
```

### 9.4 重启 serve 后配置不生效

**原因**:config.yaml 只在 serve 启动时读取一次。

**解决**:每次修改 config.yaml 后,`Ctrl+C` 停止 serve 再重新启动。

### 9.5 评审卡住不出结果

可能原因:
- 交叉验证阶段还在跑(会再发 1-2 次 API 请求)
- DeepSeek 响应慢(默认超时 300 秒)
- 大 PR 处理时间长

如超过 5 分钟未完成,观察日志是否出现 `ERROR` 或重复请求。

---

## 10. 生产部署

### 10.1 使用 GitHub App(推荐)

PAT 适合个人/测试,生产建议用 GitHub App。代码已支持(见 [webhook.py:64-131](src/ai_reviewer/github/webhook.py#L64-L131)):

```bash
export GITHUB_APP_ID=123456
export GITHUB_APP_PRIVATE_KEY="$(cat github-app.pem)"
```

GitHub App 会自动生成 installation access token,无需手动维护 PAT。

### 10.2 部署到 Cloud Run

项目已提供部署文件:

- [Dockerfile](Dockerfile)
- [cloudbuild.yaml](cloudbuild.yaml)
- [deploy-gcp.sh](deploy-gcp.sh)

部署步骤:

```bash
./deploy-gcp.sh
```

Cloud Run 会自动探活 `/health` 端点,无需额外配置。

### 10.3 安全建议

- webhook secret 必须设置(防止伪造请求)
- token 定期轮换
- 生产环境用 GitHub App 替代 PAT
- 不要把 `config.yaml` 提交到 git

---

## 11. 日志解读

### 正常流程日志

```
INFO     Triggering review via /ai-review comment on OWNER/REPO PR #N
🔍 Reviewing PR #N in OWNER/REPO...
INFO     Files changed: 15 (+217/-51)
INFO     Effective agent count: 2 (requested 3)
→ Agent status: security-reviewer-0: RUNNING
→ Agent status: patterns-reviewer-1: RUNNING
INFO     HTTP Request: POST https://api.deepseek.com/chat/completions "HTTP/1.1 200 OK"
INFO     Posted review to OWNER/REPO PR #N (COMMENT, 5 inline comments)
```

### 收敛跳过日志

```
INFO     Convergence detected for OWNER/REPO PR #N — skipping post
INFO     Pre-agent skip for OWNER/REPO PR #N: ALREADY_REVIEWED (sha=abcdef12)
```

### LGTM 快速路径日志

```
INFO     LGTM candidate for OWNER/REPO PR #N — running 1-agent re-check
INFO     LGTM for OWNER/REPO PR #N — verified clean by re-check
```

---

## 12. 相关文件

- 源码:[src/ai_reviewer/github/webhook.py](src/ai_reviewer/github/webhook.py)
- CLI:[src/ai_reviewer/cli.py](src/ai_reviewer/cli.py#L707-L730) (`serve` 命令)
- 配置:[src/ai_reviewer/config.py](src/ai_reviewer/config.py#L166) (`load_config`)
- 配置示例:[config.example.yaml](config.example.yaml)
- 部署:[Dockerfile](Dockerfile) / [cloudbuild.yaml](cloudbuild.yaml) / [deploy-gcp.sh](deploy-gcp.sh)
- 架构:[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)
- 快速启动:[QUICKSTART.md](QUICKSTART.md)
