"""Config loading tests."""

import textwrap
from pathlib import Path

from ai_reviewer.config import load_config


def test_load_deepseek_config(tmp_path: Path, monkeypatch):
    monkeypatch.setenv("DEEPSEEK_API_KEY", "sk-test-123")
    monkeypatch.setenv("GITHUB_TOKEN", "gh-test")
    cfg_file = tmp_path / "config.yaml"
    cfg_file.write_text(
        textwrap.dedent("""
        deepseek:
          api_key: ${DEEPSEEK_API_KEY}
          default_model: deepseek-v4-pro
          enable_prompt_caching: false
        github:
          token: ${GITHUB_TOKEN}
        agents:
          - name: security-reviewer
            model: deepseek-v4-pro
            focus_areas: [security]
            thinking_enabled: true
            thinking_budget_tokens: 8192
            allow_tool_use: true
            max_tool_calls: 20
    """)
    )
    cfg = load_config(cfg_file)
    assert cfg.deepseek is not None
    assert cfg.deepseek.api_key == "sk-test-123"
    assert cfg.deepseek.default_model == "deepseek-v4-pro"
    assert cfg.deepseek.enable_prompt_caching is False
    assert cfg.agents[0].thinking_enabled is True
    assert cfg.agents[0].thinking_budget_tokens == 8192
    assert cfg.agents[0].allow_tool_use is True
    assert cfg.agents[0].max_tool_calls == 20
