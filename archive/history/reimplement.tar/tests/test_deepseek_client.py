from unittest.mock import AsyncMock, MagicMock

import pytest

from ai_reviewer.agents.deepseek_client import DeepSeekClient, DeepSeekReviewResult
from ai_reviewer.config import DeepSeekApiConfig


def _text_response(text: str, finish_reason: str = "stop"):
    """Build a fake OpenAI ChatCompletion response with a text message."""
    msg = MagicMock()
    msg.content = text
    msg.tool_calls = None
    choice = MagicMock()
    choice.message = msg
    choice.finish_reason = finish_reason
    resp = MagicMock()
    resp.choices = [choice]
    resp.usage = MagicMock(prompt_tokens=100, completion_tokens=50)
    return resp


def _tool_call(id_: str, name: str, args_json: str):
    tc = MagicMock()
    tc.id = id_
    tc.function = MagicMock()
    tc.function.name = name
    tc.function.arguments = args_json
    return tc


def _tool_use_response(tool_id: str, name: str, args: dict):
    """Build a fake OpenAI response that requests a tool call."""
    import json as _json
    msg = MagicMock()
    msg.content = None
    msg.tool_calls = [_tool_call(tool_id, name, _json.dumps(args))]
    choice = MagicMock()
    choice.message = msg
    choice.finish_reason = "tool_calls"
    resp = MagicMock()
    resp.choices = [choice]
    resp.usage = MagicMock(prompt_tokens=10, completion_tokens=5)
    return resp


@pytest.mark.asyncio
async def test_run_review_happy_path_parses_json():
    cfg = DeepSeekApiConfig(api_key="sk-test")
    client = DeepSeekClient(cfg)
    client._sdk = MagicMock()
    client._sdk.chat.completions.create = AsyncMock(
        return_value=_text_response('{"findings": [], "summary": "ok"}')
    )

    result = await client.run_review(
        model="deepseek-v4-pro",
        system_blocks=[{"type": "text", "text": "You are a reviewer."}],
        user_blocks=[{"type": "text", "text": "diff..."}],
        output_schema={"type": "object"},
        tool_registry=None,
        enable_thinking=False,
        max_tokens=4096,
        temperature=0.3,
    )

    assert isinstance(result, DeepSeekReviewResult)
    assert result.parsed == {"findings": [], "summary": "ok"}
    assert result.usage.input_tokens == 100


@pytest.mark.asyncio
async def test_run_review_uses_json_object_response_format_without_tools():
    cfg = DeepSeekApiConfig(api_key="sk-test")
    client = DeepSeekClient(cfg)
    client._sdk = MagicMock()
    client._sdk.chat.completions.create = AsyncMock(
        return_value=_text_response('{"findings": [], "summary": "ok"}')
    )

    await client.run_review(
        model="deepseek-v4-pro",
        system_blocks=[{"type": "text", "text": "sys"}],
        user_blocks=[{"type": "text", "text": "u"}],
        output_schema={"type": "object"},
        tool_registry=None,
        enable_thinking=False,
        max_tokens=4096,
        temperature=0.3,
    )

    kwargs = client._sdk.chat.completions.create.call_args.kwargs
    assert kwargs["response_format"] == {"type": "json_object"}
    assert "tools" not in kwargs


@pytest.mark.asyncio
async def test_run_review_with_tools_omits_response_format():
    cfg = DeepSeekApiConfig(api_key="sk-test")
    client = DeepSeekClient(cfg)
    client._sdk = MagicMock()
    client._sdk.chat.completions.create = AsyncMock(
        return_value=_text_response('{"findings": [], "summary": "ok"}')
    )

    registry = MagicMock()
    registry.tool_specs.return_value = [
        {"type": "function", "function": {"name": "read_file", "parameters": {}}}
    ]

    await client.run_review(
        model="deepseek-v4-pro",
        system_blocks=[{"type": "text", "text": "s"}],
        user_blocks=[{"type": "text", "text": "u"}],
        output_schema={"type": "object"},
        tool_registry=registry,
        enable_thinking=False,
        max_tokens=4096,
        temperature=0.3,
    )

    kwargs = client._sdk.chat.completions.create.call_args.kwargs
    assert "response_format" not in kwargs
    assert kwargs["tools"] == registry.tool_specs.return_value


@pytest.mark.asyncio
async def test_tool_use_loop_dispatches_and_feeds_result_back():
    cfg = DeepSeekApiConfig(api_key="sk-test")
    client = DeepSeekClient(cfg)
    client._sdk = MagicMock()
    client._sdk.chat.completions.create = AsyncMock(
        side_effect=[
            _tool_use_response("t1", "read_file", {"path": "x.py"}),
            _text_response('{"findings": [], "summary": "done"}'),
        ]
    )

    registry = MagicMock()
    registry.tool_specs.return_value = [
        {"type": "function", "function": {"name": "read_file", "parameters": {}}}
    ]
    registry.execute = AsyncMock(return_value="file-contents")

    result = await client.run_review(
        model="deepseek-v4-pro",
        system_blocks=[{"type": "text", "text": "s"}],
        user_blocks=[{"type": "text", "text": "u"}],
        output_schema={"type": "object"},
        tool_registry=registry,
        enable_thinking=False,
        max_tokens=4096,
        temperature=0.3,
    )

    assert result.parsed == {"findings": [], "summary": "done"}
    registry.execute.assert_awaited_once_with("read_file", {"path": "x.py"})
    assert client._sdk.chat.completions.create.await_count == 2

    second_kwargs = client._sdk.chat.completions.create.await_args_list[1].kwargs
    last_msg = second_kwargs["messages"][-1]
    assert last_msg["role"] == "tool"
    assert last_msg["tool_call_id"] == "t1"
    assert last_msg["content"] == "file-contents"


@pytest.mark.asyncio
async def test_run_completion_returns_plain_text():
    cfg = DeepSeekApiConfig(api_key="sk-test")
    client = DeepSeekClient(cfg)
    client._sdk = MagicMock()
    client._sdk.chat.completions.create = AsyncMock(
        return_value=_text_response("# Updated README\n\nNew content here.")
    )

    result = await client.run_completion(
        model="deepseek-v4-pro",
        system="You are a technical writer.",
        user="Update these docs.",
        max_tokens=2048,
    )

    assert result == "# Updated README\n\nNew content here."
    call_kwargs = client._sdk.chat.completions.create.call_args.kwargs
    assert call_kwargs["model"] == "deepseek-v4-pro"
    assert call_kwargs["max_tokens"] == 2048
    # run_completion must not pass tools or response_format
    assert "tools" not in call_kwargs
    assert "response_format" not in call_kwargs


@pytest.mark.asyncio
async def test_run_completion_uses_system_and_user():
    cfg = DeepSeekApiConfig(api_key="sk-test")
    client = DeepSeekClient(cfg)
    client._sdk = MagicMock()
    client._sdk.chat.completions.create = AsyncMock(return_value=_text_response("result"))

    await client.run_completion(
        model="deepseek-v4-pro",
        system="sys prompt",
        user="user prompt",
    )

    call_kwargs = client._sdk.chat.completions.create.call_args.kwargs
    assert call_kwargs["messages"][0] == {"role": "system", "content": "sys prompt"}
    assert call_kwargs["messages"][1] == {"role": "user", "content": "user prompt"}


@pytest.mark.asyncio
async def test_run_review_strips_markdown_code_fences_from_json():
    cfg = DeepSeekApiConfig(api_key="sk-test")
    client = DeepSeekClient(cfg)
    client._sdk = MagicMock()
    client._sdk.chat.completions.create = AsyncMock(
        return_value=_text_response('```json\n{"findings": [], "summary": "ok"}\n```')
    )

    result = await client.run_review(
        model="deepseek-v4-pro",
        system_blocks=[{"type": "text", "text": "s"}],
        user_blocks=[{"type": "text", "text": "u"}],
        output_schema={"type": "object"},
        tool_registry=None,
        enable_thinking=False,
        max_tokens=4096,
        temperature=0.3,
    )

    assert result.parsed == {"findings": [], "summary": "ok"}
